import React, {Component} from 'react';
import './navbar.css'

class NavBar extends Component {

  render(){
    return (


        <nav>
          <ul>
            <li className="logo">logo</li>
            <li>upload</li>
            <li>login</li>
          </ul>
        </nav>


    )
  }
}


export default NavBar;